#!/bin/sh
xrandr --output HDMI-1 --off --output DP-1 --off --output eDP-1 --mode 1920x1080 --pos 0x0 --rotate normal --output HDMI-2  --same-as HDMI-1 --mode 1920x1080 --pos 1920x0 --rotate normal
