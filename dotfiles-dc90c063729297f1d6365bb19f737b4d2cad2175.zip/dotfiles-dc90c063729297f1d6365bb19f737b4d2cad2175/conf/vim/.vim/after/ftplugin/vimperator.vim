setlocal commentstring=\"\ %s
