setlocal spell
