(setq-default
  dotspacemacs-default-font '("Iosevka"
                              :size 24
                              :weight normal
                              :width normal
                              :powerline-scale 1.1))

; dotspacemacs-default-font (load-file (concat "~/.spacemacs.d/local/" system-name ".el"))
; :size (if (string= system-name "allitnil") 15 13)
